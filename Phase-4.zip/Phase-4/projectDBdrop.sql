-- Drop the 'promotiononproducts' table
DROP TABLE F23_S002_T4_promotiononproducts;

-- Drop the 'customerbuysproducts' table
DROP TABLE F23_S002_T4_customerbuysproducts;

-- Drop the 'customerbenefitsfrompromotion' table
DROP TABLE F23_S002_T4_customerbenefitsfrompromotion;

-- Drop the 'staffsellsproducts' table
DROP TABLE F23_S002_T4_staffsellsproducts;

-- Drop the 'staffdoespromotion' table
DROP TABLE F23_S002_T4_staffdoespromotion;

-- Drop the 'purchase' table
DROP TABLE F23_S002_T4_purchase;

-- Drop the 'products_model' table
DROP TABLE F23_S002_T4_products_model;

-- Drop the 'products_brand' table
DROP TABLE F23_S002_T4_products_brand;

-- Drop the 'products' table
DROP TABLE F23_S002_T4_products;

-- Drop the 'promotion' table
DROP TABLE F23_S002_T4_promotion;

-- Drop the 'customer' table
DROP TABLE F23_S002_T4_customer;

-- Drop the 'staff' table
DROP TABLE F23_S002_T4_staff;

-- Drop the 'person_phone' table
DROP TABLE F23_S002_T4_person_phone;

-- Drop the 'person_email' table
DROP TABLE F23_S002_T4_person_email;

-- Drop the 'person' table
DROP TABLE F23_S002_T4_person;

